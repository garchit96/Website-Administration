import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManageUsersService } from '../manage-users.service';
import { AuthService } from '../services/auth.service';
import { Users } from '../User';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  title = 'Admin';
  constructor(private router: Router, private authService: AuthService, private manageuser: ManageUsersService) { }
  allUser:Users[];
  email: string;  
  displayUser = false;
  displayUserGroup = false;
 
  listUser() {
    // if(this.displayUserGroup== true){
    //   this.displayUserGroup = !this.displayUserGroup;
    // }
    this.displayUser = !this.displayUser;
    this.router.navigateByUrl('/admin/users');
    // this.getAllUsers();

  }

  listUserGroup() {
    
    this.displayUserGroup = !this.displayUserGroup;
  }
  
 
  ngOnInit(): void {
    // this.getAllUsers();
    // this.email = localStorage.getItem('token');  
    //console.log(this.id);  
  }

  // logout() {  
  //   console.log('logout');  
  //   this.authService.logout();  
  //   this.router.navigate(['/home']);  
  // }  

}
