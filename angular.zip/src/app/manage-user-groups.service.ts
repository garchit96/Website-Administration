import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from './User';
import { UserGroups } from './usergroups';



const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}  
@Injectable({
  providedIn: 'root'
})
export class ManageUserGroupsService {

  constructor(private httpClient:HttpClient) { }

  viewAllGroupUsers(groupName:string):Observable<Users[]>{
    const userGroupUrl='http://localhost:3000/users?GroupName=groupName';
    return this.httpClient.get<Users[]>(userGroupUrl,httpOption);
  }
  
  viewAllUserGroups(): Observable<UserGroups[]>{
    const userUrl='http://localhost:9090/service/usergroups';
    // return this.httpClient.get<Users>(userUrl);//return observable
    return this.httpClient.get<UserGroups[]>(userUrl);
  }

  deleteUserGroup(id:number):Observable<UserGroups>{
    const userGroupUrl='http://localhost:3000/usergroups';
    return this.httpClient.delete<UserGroups>(userGroupUrl+'/'+id, httpOption);//return observable
  }
  
  createUserGroup(usergroup:UserGroups):Observable<UserGroups>{
    const userGroupUrl='http://localhost:3000/usergroups';
    return this.httpClient.post<UserGroups>(userGroupUrl, usergroup,httpOption);//return observable
  }

  viewUserGroupById(id:number): Observable<UserGroups>{
    const userGroupUrl='http://localhost:3000/usergroups/'+id;
    return this.httpClient.get<UserGroups>(userGroupUrl);//return observable
  }
  

  updateUserGroup(data:any, id:number):Observable<UserGroups>{
    const userGroupUrl='http://localhost:3000/usergroups';
    return this.httpClient.put<UserGroups>(userGroupUrl + '/'+id, data, httpOption);//return observable
  }
}
