export class UserLogin {      
    userName: string;    
    userPassword: string;    
 }   