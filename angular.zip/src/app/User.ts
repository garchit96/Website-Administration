import { UserGroups } from "./usergroups";

export interface Users{
    user_id: number;
    name:string;
    email:string;
    address:string;
    usergroup:UserGroups
    // groupId:number;
}