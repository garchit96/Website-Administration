import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ManageUsersService } from '../manage-users.service';
import { Users } from '../User';

import { FormsModule } from '@angular/forms'
import { userModel } from '../userModel';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  formValue :FormGroup;
  userObj :userModel= new userModel();
  allUser:Users[];
  showAdd=false;
  showUpdate=true;
  searchValue:string;

  currentUser=null;

  lock=false;

  constructor(private readonly formBuilder:FormBuilder, private manageuser: ManageUsersService, private router: Router,  private route: ActivatedRoute,) { }

  get email(){
    return this.formValue.get('email')
  }

  // get PhoneNumber(){
  //   return this.formValue.get('PhoneNumber')
  // }
  get address(){
    return this.formValue.get('address')
  }

  get name(){
    return this.formValue.get('name')
  }
  get usergroup(){
    return this.formValue.get('usergroup')
  }

  ngOnInit() {
    this.getAllUsers();
    this.formValue = this.formBuilder.group({
      // user_id: ['', [Validators.required]],
      name: ['',[Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      address: ['', [Validators.required]],
      usergroup: ['', [Validators.required]]
    });

    // this.getUser(this.route.snapshot.paramMap.get('id'));
  }

  clickAddUser(){
    this.formValue.reset();
   this.showAdd=true;
   this.showUpdate=false;

  }

  userLock(user){
    if(this.lock==false){
      this.lock=true;
    }
    else{
      this.lock=false;
    }
    console.log(this.lock)
    
  }

  addUser(){
    this.userObj.name=this.formValue.value.name;
    this.userObj.email=this.formValue.value.email;
    // this.userObj.PhoneNumber=this.formValue.value.PhoneNumber;
    this.userObj.address=this.formValue.value.address;
    // this.userObj.groupId=this.formValue.value.groupId;

    this.manageuser.createUser(this.userObj)
    .subscribe(res=>{
      console.log(res);
      alert("User Added Successfully")
      this.formValue.reset();
      // this.getAllUsers();
    })
  }

  getAllUsers(){
    this.manageuser.viewAllUser().subscribe((data:Users[])=>{
        this.allUser=data;
      });
  }
  deleteUser(id:number){
    if(confirm('Are you sure to delete??')){
      this.manageuser.deleteUser(id).subscribe(res=>{
          this.getAllUsers();
          alert("User Deleted!!")
      }  
        );
    }
    

  }

  // updateUser(user){
  // this.manageuser.currentUser=Object.assign({},user)
  // }

  editUser(user){
    this.showAdd=false;
   this.showUpdate=true;
    this.userObj.user_id=user.user_id;
    this.formValue.controls['name'].setValue(user.name)
    this.formValue.controls['email'].setValue(user.email)
    this.formValue.controls['address'].setValue(user.address)
    this.formValue.controls['groupId'].setValue(user.groupId)
    
    // this.submitted=true;
    // this.currentUser=user;
    }

    updateUser(){
      this.userObj.name=this.formValue.value.name;
      this.userObj.email=this.formValue.value.email;
      
      this.userObj.address=this.formValue.value.address;
      this.userObj.usergroup=this.formValue.value.groupId;

      this.manageuser.updateUser(this.userObj,this.userObj.user_id)
      .subscribe(data=>{
        alert("Updated Successfully!!");
        this.formValue.reset();
        this.getAllUsers();
      })
    }

    getUser(id): void {
      this.manageuser.viewUserById(id)
        .subscribe(
          data => {
            this.currentUser = data;
            console.log(data);
          },
          error => {
            console.log(error);
          });
    }
  
 

}
