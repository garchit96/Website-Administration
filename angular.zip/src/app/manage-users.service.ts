import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from './User';



const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}  
@Injectable(
  {
  providedIn: 'root'
}
)
export class ManageUsersService {

  // currentUser: Users={
  //   id:null,
  //   FullName:'',
  //   email:'',
  //   password:''
  // }
  constructor(private httpClient:HttpClient) { } 

  // userUrl='http://localhost:9090/service/users';

  viewAllUser(): Observable<Users[]>{
    const userUrl='http://localhost:9090/service/users';
    // return this.httpClient.get<Users>(userUrl);//return observable
    return this.httpClient.get<Users[]>(userUrl);
  }

  deleteUser(id:number): Observable<any> {
    const userUrl='http://localhost:9090/service/users/deleteUser';
    return this.httpClient.delete(userUrl+'/'+id);
  }
  // deleteUser(id:number):Observable<Users>{
  //   const userUrl='http://localhost:9090/service/users/deleteUser';
    
  //   return this.httpClient.delete<Users>(`${userUrl}/${id}`);
  //   // return this.httpClient.delete<Users>(userUrl+'/deleteUser?id='+id);//return observable
  // }
  
  createUser(user:Users):Observable<Users>{
    const userUrl='http://localhost:9090/service/users/addUser';
    return this.httpClient.post<Users>(userUrl, user);//return observable
  }

  viewUserById(id:number): Observable<any>{
    const userUrl='http://localhost:9090/service/users'+id;
    return this.httpClient.get<Users>(userUrl);//return observable
  }

  
  

  updateUser(data:any, id:number):Observable<Users>{
    const userUrl='http://localhost:9090/service/users';
    return this.httpClient.put<Users>(userUrl + '/'+id, data, httpOption);//return observable
  }


 

}


