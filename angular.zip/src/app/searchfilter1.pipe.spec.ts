import { Searchfilter1Pipe } from './searchfilter1.pipe';

describe('Searchfilter1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Searchfilter1Pipe();
    expect(pipe).toBeTruthy();
  });
});
