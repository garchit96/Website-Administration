import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-helpdesk',
  templateUrl: './helpdesk.component.html',
  styleUrls: ['./helpdesk.component.css']
})
export class HelpdeskComponent implements OnInit {
  title = 'HelpDesk';
  constructor(private router: Router, private authService: AuthService) { }
  email: string;
  displayUser = false;
  displayUserGroup = false;
 
  listUser() {
    // if(this.displayUserGroup== true){
    //   this.displayUserGroup = !this.displayUserGroup;
    // }
    this.displayUser = !this.displayUser;
    this.router.navigateByUrl('/helpdesk/users');
    // this.getAllUsers();

  }
  
  
  ngOnInit(): void {
    // this.email = localStorage.getItem('token');
  }

  // logout() {  
  //   console.log('logout');  
  //   this.authService.logout();  
  //   this.router.navigate(['/home']);  
  // }  

}
