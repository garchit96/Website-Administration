export interface UserGroups{
    id: number;
    name:string;
    email:string;
    
}