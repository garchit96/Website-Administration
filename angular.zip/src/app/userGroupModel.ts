export class userGroupModel{
    id: number=0;
    name:string='';
    email:string='';
    
}