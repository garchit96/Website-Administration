import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Users } from '../User';
import { UserLogin } from 'src/app/login'; 
import { LoginService } from '../services/login.service';


// import { Router } from '@angular/router';
// import { map } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit  {

  

  // model1: UserLogin = { email: "admin@gmail.com", password: "admin@123" } 
  // model2: UserLogin = { email: "help@gmail.com", password: "help@123" } 
  loginFormGroup: FormGroup;  
  message: string;  
  returnUrl1: string; 
  returnUrl2: string; 
  isSubmitted  =  false;
  
  
  constructor(
    private loginService:LoginService,
    private formBuilder : FormBuilder,
    private authService : AuthService ,
    private router:Router
  ) { }
  // loginFormGroup=new FormGroup({
  //   email: new FormControl('',[Validators.required,Validators.email]),
  //   password: new FormControl('',[Validators.required,Validators.minLength(6)])
  // })
  ngOnInit(): void {
    this.loginFormGroup = this.formBuilder.group({  
      // email: ['', Validators.required, Validators.email],  
      userName: ['', Validators.required], 
      userPassword: ['', Validators.required]  
   });  
// this.returnUrl1 = '/admin';  
// this.returnUrl2 = '/helpdesk'; 
// this.authService.logout();  
  }

  
get f() { return this.loginFormGroup.controls; }

 

  // onSubmit(){
  //     this.isSubmitted = true;
          
  //           console.log("We need to submit the login form");
  //           this.loginService.generateToken(this.loginFormGroup.value).subscribe(
  //             (response:any)=>{
  //               console.log(response.token);
  //               this.loginService.loginUser(response.token)
  //               window.location.href="/admin"
  
  //         },
  //         error=>{
  //           console.log(error);
  //         }
          
  //       )
  //     }

      login(){
        this.loginService.login(this.loginFormGroup.value).subscribe(

          (response: any) => {
            this.authService.setRoles(response.user.role);
            this.authService.setToken(response.jwtToken);
    
            const role = response.user.role[0].roleName;
            if (role === 'Admin') {
              this.router.navigate(['/admin']);
            } else {
              this.router.navigate(['/helpdesk']);
            }
          },
          (error) => {
            console.log(error);
          }
        );
      }

  }
     
    
    
 

  
  

