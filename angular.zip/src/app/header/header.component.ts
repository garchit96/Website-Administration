import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from '../services/auth.service';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  displayUser = false;
  displayUserGroup = false;
  public loggedIn=false;

  constructor(public router:Router, private authService: AuthService, public loginService:LoginService){
  }

  public isLoggedIn() {
    return this.authService.isLoggedIn();
  }

  listadminUser() {
    // if(this.displayUserGroup== true){
    //   this.displayUserGroup = !this.displayUserGroup;
    // }
    this.displayUser = !this.displayUser;
    this.router.navigateByUrl('/admin/users');
    // this.getAllUsers();

  }
  listhelpdeskUser() {
    // if(this.displayUserGroup== true){
    //   this.displayUserGroup = !this.displayUserGroup;
    // }
    this.displayUser = !this.displayUser;
    this.router.navigateByUrl('/helpdesk/users');
    // this.getAllUsers();

  }

  
  listadminUserGroup() {
    
    this.displayUserGroup = !this.displayUserGroup;
    this.router.navigateByUrl('/admin/usergroups');
  }

  logout() {  
   
    this.authService.clear();  
    this.router.navigate(['/home']);
   
  }  

  ngOnInit(): void {
    // this.loggedIn=this.loginService.isLoggedIn();
    
  }

  // logoutUser(){
  //   this.loginService.logout();
  //   location.reload();
  // }

  


}
