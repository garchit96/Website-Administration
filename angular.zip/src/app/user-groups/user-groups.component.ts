import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ManageUserGroupsService } from '../manage-user-groups.service';
import { ManageUsersService } from '../manage-users.service';
import { Users } from '../User';

import { userGroupModel } from '../userGroupModel';
import { UserGroups } from '../usergroups';


@Component({
  selector: 'app-user-groups',
  templateUrl: './user-groups.component.html',
  styleUrls: ['./user-groups.component.css']
})
export class UserGroupsComponent implements OnInit {
  formValue :FormGroup;
  userGroupObj :userGroupModel= new userGroupModel();
  allUserGroups:UserGroups[];
  showAdd=false;
  showUpdate=true;
  searchValue1;
  searchValue;;
lock=false;
  manageuser: any;
  // allUser: any[];
  allUser:Users[];

  constructor(private readonly formBuilder:FormBuilder, private manageusergroups: ManageUserGroupsService, private router: Router) { }

  get email(){
    return this.formValue.get('email')
  }

  // get Area(){
  //   return this.formValue.get('Area')
  // }
  // get UsersCount(){
  //   return this.formValue.get('UsersCount')
  // }

  get name(){
    return this.formValue.get('name')
  }

  ngOnInit(): void {
    this.getAllUserGroups();
   
    this.formValue = this.formBuilder.group({
      // userId: ['', [Validators.required]],
      name: ['',[Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      created_on:['',[Validators.required]]
      // Area: ['', [Validators.required]],
      // UsersCount: ['', [Validators.required]]

    });
  }

  clickAddUserGroup(){
    this.formValue.reset();
   this.showAdd=true;
   this.showUpdate=false;

  }

  userGroupLock(){
    if(this.lock==false){
      this.lock=true;
    }
    else{
      this.lock=false;
    }
    console.log(this.lock)
    
  }

  addUserGroup(){
    this.userGroupObj.name=this.formValue.value.name;
    this.userGroupObj.email=this.formValue.value.email;
    // this.userGroupObj.Area=this.formValue.value.Area;
    // this.userGroupObj.UsersCount=this.formValue.value.UsersCount;


    this.manageusergroups.createUserGroup(this.userGroupObj)
    .subscribe(res=>{
      console.log(res);
      alert("UserGroup Added Successfully")
      this.formValue.reset();
      // this.getAllUsers();
    })
  }

  getAllUserGroups(){
    this.manageusergroups.viewAllUserGroups().subscribe((data:UserGroups[])=>{
        this.allUserGroups=data;
      });
  }
  getAllGroupUsers(name:string){
    this.manageuser.viewAllGroupUsers(name).subscribe((data:Users[])=>{
        this.allUser=data;
      });
  }

  deleteUserGroup(id:number){
    // console.log(id);
    this.manageusergroups.deleteUserGroup(id).subscribe(
      (data:UserGroups) =>{
        alert("User Deleted!!")
        this.getAllUserGroups();
      });

  }

  editUserGroup(userGroup){
    this.showAdd=false;
   this.showUpdate=true;
    this.userGroupObj.id=userGroup.id;
    this.formValue.controls['name'].setValue(userGroup.name)
    this.formValue.controls['email'].setValue(userGroup.email)
    // this.formValue.controls['Area'].setValue(userGroup.Area)
    // this.formValue.controls['UsersCount'].setValue(userGroup.UsersCount)
    // this.submitted=true;
    // this.currentUser=user;
    }

    updateUserGroup(){
      this.userGroupObj.name=this.formValue.value.name;
      this.userGroupObj.email=this.formValue.value.email;
      // this.userGroupObj.Area=this.formValue.value.Area;
      // this.userGroupObj.UsersCount=this.formValue.value.UsersCount;


      this.manageusergroups.updateUserGroup(this.userGroupObj,this.userGroupObj.id)
      .subscribe(data=>{
        alert("Updated Successfully!!");
        this.formValue.reset();
        this.getAllUserGroups();
      })
    }
  }
