import { UserGroups } from "./usergroups";

export class userModel{
    user_id: number=0;
    name:string='';
    email:string='';
    address:string='';
    usergroup:UserGroups;

}